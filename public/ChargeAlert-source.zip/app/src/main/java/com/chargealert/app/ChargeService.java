package com.chargealert.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.IBinder;
import android.os.Vibrator;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Set;

public class ChargeService extends Service {
    public static final String ACTION_STOP_SERVICE = "com.chargealert.app.ACTION_STOP";
    public static final String ACTION_DISMISS_ALARM = "com.chargealert.app.ACTION_DISMISS_ALARM";
    public static final String CHANNEL_ID_MONITOR = "charge_alert_monitor";
    public static final String CHANNEL_ID_ALARM = "charge_alert_alarm";
    public static final int NOTIF_ID_MONITOR = 1001;
    public static final int NOTIF_ID_ALARM = 1002;

    private static boolean isServiceRunning = false;
    private BroadcastReceiver batteryReceiver;
    private final Set<Integer> triggeredThresholds = new HashSet<Integer>();
    private Ringtone currentRingtone;
    private boolean isAlarmPlaying = false;

    public static boolean isRunning() {
        return isServiceRunning;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        isServiceRunning = true;
        createNotificationChannels();
        registerBatteryReceiver();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_STOP_SERVICE.equals(action)) {
                stopAlarm();
                stopForeground(true);
                stopSelf();
                return START_NOT_STICKY;
            } else if (ACTION_DISMISS_ALARM.equals(action)) {
                stopAlarm();
                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) {
                    nm.cancel(NOTIF_ID_ALARM);
                }
                return START_STICKY;
            }
        }

        startForeground(NOTIF_ID_MONITOR, buildMonitorNotification(0, false));
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isServiceRunning = false;
        stopAlarm();
        if (batteryReceiver != null) {
            try {
                unregisterReceiver(batteryReceiver);
            } catch (Exception ignored) {}
            batteryReceiver = null;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void registerBatteryReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_BATTERY_CHANGED);
        filter.addAction(Intent.ACTION_POWER_CONNECTED);
        filter.addAction(Intent.ACTION_POWER_DISCONNECTED);

        batteryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null) return;
                String action = intent.getAction();

                if (Intent.ACTION_POWER_DISCONNECTED.equals(action)) {
                    // Charger unplugged -> reset triggered alerts and stop alarm chime
                    triggeredThresholds.clear();
                    stopAlarm();
                    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    if (nm != null) {
                        nm.cancel(NOTIF_ID_ALARM);
                    }
                    updateMonitorNotification(0, false);
                    return;
                }

                if (Intent.ACTION_BATTERY_CHANGED.equals(action)) {
                    int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                    int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);

                    int pct = (scale > 0) ? (level * 100 / scale) : level;
                    boolean isCharging = (status == BatteryManager.BATTERY_STATUS_CHARGING ||
                                          status == BatteryManager.BATTERY_STATUS_FULL);

                    updateMonitorNotification(pct, isCharging);

                    if (isCharging) {
                        checkThresholds(pct);
                    }
                }
            }
        };

        registerReceiver(batteryReceiver, filter);
    }

    private void checkThresholds(int currentPct) {
        SharedPreferences sp = getSharedPreferences("ChargeAlertPrefs", MODE_PRIVATE);
        int[] availableThresholds = new int[]{70, 75, 80, 85, 90, 95, 100};

        for (int t : availableThresholds) {
            boolean enabled = sp.getBoolean("thresh_" + t, (t == 80 || t == 100));
            if (enabled && currentPct >= t && !triggeredThresholds.contains(t)) {
                triggeredThresholds.add(t);
                fireAlert(currentPct, t);
                break;
            }
        }
    }

    private void fireAlert(int currentPct, int threshold) {
        SharedPreferences sp = getSharedPreferences("ChargeAlertPrefs", MODE_PRIVATE);
        boolean soundEnabled = sp.getBoolean("opt_sound", true);
        boolean vibrateEnabled = sp.getBoolean("opt_vibrate", true);

        if (soundEnabled) {
            playAlertSound();
        }

        if (vibrateEnabled) {
            vibrateDevice();
        }

        showAlarmNotification(currentPct, threshold);
    }

    private void playAlertSound() {
        try {
            stopAlarm();
            Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (soundUri == null) {
                soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            }
            currentRingtone = RingtoneManager.getRingtone(getApplicationContext(), soundUri);
            if (currentRingtone != null) {
                if (Build.VERSION.SDK_INT >= 21) {
                    try {
                        AudioAttributes attrs = new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_ALARM)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build();
                        Method setAudioAttributes = Ringtone.class.getMethod("setAudioAttributes", AudioAttributes.class);
                        setAudioAttributes.invoke(currentRingtone, attrs);
                    } catch (Exception ignored) {}
                }
                currentRingtone.play();
                isAlarmPlaying = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void vibrateDevice() {
        try {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) {
                long[] pattern = new long[]{0, 500, 200, 500, 200, 800};
                v.vibrate(pattern, -1);
            }
        } catch (Exception ignored) {}
    }

    public void stopAlarm() {
        try {
            if (currentRingtone != null && currentRingtone.isPlaying()) {
                currentRingtone.stop();
            }
        } catch (Exception ignored) {}
        currentRingtone = null;
        isAlarmPlaying = false;
    }

    private void updateMonitorNotification(int pct, boolean isCharging) {
        Notification n = buildMonitorNotification(pct, isCharging);
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(NOTIF_ID_MONITOR, n);
        }
    }

    private Notification buildMonitorNotification(int pct, boolean isCharging) {
        String title = "Charge Alert Active";
        String text = isCharging
                ? ("Charging: " + (pct > 0 ? (pct + "%") : "detecting...") + " • Monitoring thresholds")
                : ("Unplugged: " + (pct > 0 ? (pct + "%") : "") + " • Connect charger to monitor");

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pOpen = PendingIntent.getActivity(this, 0, openIntent,
                Build.VERSION.SDK_INT >= 23 ? (PendingIntent.FLAG_UPDATE_CURRENT | 0x04000000 /* FLAG_IMMUTABLE */) : PendingIntent.FLAG_UPDATE_CURRENT);

        Intent stopIntent = new Intent(this, ChargeService.class);
        stopIntent.setAction(ACTION_STOP_SERVICE);
        PendingIntent pStop = PendingIntent.getService(this, 1, stopIntent,
                Build.VERSION.SDK_INT >= 23 ? (PendingIntent.FLAG_UPDATE_CURRENT | 0x04000000 /* FLAG_IMMUTABLE */) : PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder b = createNotificationBuilder(CHANNEL_ID_MONITOR);
        b.setContentTitle(title)
         .setContentText(text)
         .setSmallIcon(R.drawable.ic_launcher)
         .setContentIntent(pOpen)
         .setOngoing(true)
         .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Service", pStop);

        return b.build();
    }

    private void showAlarmNotification(int currentPct, int threshold) {
        Intent dismissIntent = new Intent(this, ChargeService.class);
        dismissIntent.setAction(ACTION_DISMISS_ALARM);
        PendingIntent pDismiss = PendingIntent.getService(this, 2, dismissIntent,
                Build.VERSION.SDK_INT >= 23 ? (PendingIntent.FLAG_UPDATE_CURRENT | 0x04000000 /* FLAG_IMMUTABLE */) : PendingIntent.FLAG_UPDATE_CURRENT);

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pOpen = PendingIntent.getActivity(this, 3, openIntent,
                Build.VERSION.SDK_INT >= 23 ? (PendingIntent.FLAG_UPDATE_CURRENT | 0x04000000 /* FLAG_IMMUTABLE */) : PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder b = createNotificationBuilder(CHANNEL_ID_ALARM);
        b.setContentTitle("Battery Reached " + threshold + "%!")
         .setContentText("Target charge level reached. Unplug your device to protect battery health.")
         .setSmallIcon(R.drawable.ic_launcher)
         .setContentIntent(pOpen)
         .setAutoCancel(true)
         .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Dismiss Chime", pDismiss);

        if (Build.VERSION.SDK_INT >= 21) {
            b.setPriority(Notification.PRIORITY_MAX);
            b.setCategory(Notification.CATEGORY_ALARM);
        }

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(NOTIF_ID_ALARM, b.build());
        }
    }

    private Notification.Builder createNotificationBuilder(String channelId) {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                Constructor<Notification.Builder> c = Notification.Builder.class.getConstructor(Context.class, String.class);
                return c.newInstance(this, channelId);
            } catch (Exception ignored) {}
        }
        return new Notification.Builder(this);
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                Class<?> channelClass = Class.forName("android.app.NotificationChannel");
                Constructor<?> c = channelClass.getConstructor(String.class, CharSequence.class, int.class);

                // Monitor channel (importance min/low)
                Object monChannel = c.newInstance(CHANNEL_ID_MONITOR, "Monitoring Service", 2 /* IMPORTANCE_LOW */);
                Method setSound = channelClass.getMethod("setSound", Uri.class, AudioAttributes.class);
                setSound.invoke(monChannel, null, null);

                // Alarm channel (importance high)
                Object alarmChannel = c.newInstance(CHANNEL_ID_ALARM, "Charge Alerts", 4 /* IMPORTANCE_HIGH */);

                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                Method createChannel = NotificationManager.class.getMethod("createNotificationChannel", channelClass);
                createChannel.invoke(nm, monChannel);
                createChannel.invoke(nm, alarmChannel);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
