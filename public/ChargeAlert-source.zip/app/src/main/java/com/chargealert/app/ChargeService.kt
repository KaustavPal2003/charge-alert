package com.chargealert.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.os.Vibrator

class ChargeService : Service() {
    companion object {
        const val ACTION_STOP_SERVICE = "com.chargealert.app.ACTION_STOP"
        const val ACTION_DISMISS_ALARM = "com.chargealert.app.ACTION_DISMISS_ALARM"
        const val CHANNEL_MONITOR = "charge_alert_monitor"
        const val CHANNEL_ALARM = "charge_alert_alarm"
        const val NOTIF_ID_MONITOR = 1001
        const val NOTIF_ID_ALARM = 1002

        val THRESHOLDS = intArrayOf(70, 75, 80, 85, 90, 95, 100)
        var isServiceRunning = false
            private set
    }

    private var batteryReceiver: BroadcastReceiver? = null
    private val triggeredThresholds = mutableSetOf<Int>()
    private var currentRingtone: Ringtone? = null

    override fun onCreate() {
        super.onCreate()
        isServiceRunning = true
        createNotificationChannels()
        registerBatteryReceiver()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_SERVICE -> {
                stopAlarm()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_DISMISS_ALARM -> {
                stopAlarm()
                val nm = getSystemService(NotificationManager::class.java)
                nm?.cancel(NOTIF_ID_ALARM)
                return START_STICKY
            }
        }

        startForeground(NOTIF_ID_MONITOR, buildMonitorNotification(0, false))
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        isServiceRunning = false
        stopAlarm()
        batteryReceiver?.let {
            unregisterReceiver(it)
            batteryReceiver = null
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun registerBatteryReceiver() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        }

        batteryReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent == null) return

                if (intent.action == Intent.ACTION_POWER_DISCONNECTED) {
                    triggeredThresholds.clear()
                    stopAlarm()
                    val nm = getSystemService(NotificationManager::class.java)
                    nm?.cancel(NOTIF_ID_ALARM)
                    updateMonitorNotification(0, false)
                    return
                }

                if (intent.action == Intent.ACTION_BATTERY_CHANGED) {
                    val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                    val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                    val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                    val pct = if (scale > 0) (level * 100 / scale) else level
                    val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                                     status == BatteryManager.BATTERY_STATUS_FULL

                    updateMonitorNotification(pct, isCharging)

                    if (isCharging) {
                        checkThresholds(pct)
                    }
                }
            }
        }
        registerReceiver(batteryReceiver, filter)
    }

    private fun checkThresholds(currentPct: Int) {
        val sp = getSharedPreferences("ChargeAlertPrefs", MODE_PRIVATE)
        for (t in THRESHOLDS) {
            val enabled = sp.getBoolean("thresh_$t", t == 80 || t == 100)
            if (enabled && currentPct >= t && !triggeredThresholds.contains(t)) {
                triggeredThresholds.add(t)
                fireAlert(currentPct, t)
                break
            }
        }
    }

    private fun fireAlert(currentPct: Int, threshold: Int) {
        val sp = getSharedPreferences("ChargeAlertPrefs", MODE_PRIVATE)
        if (sp.getBoolean("opt_sound", true)) playAlertSound()
        if (sp.getBoolean("opt_vibrate", true)) vibrateDevice()
        showAlarmNotification(currentPct, threshold)
    }

    private fun playAlertSound() {
        try {
            stopAlarm()
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            currentRingtone = RingtoneManager.getRingtone(applicationContext, uri)
            currentRingtone?.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            currentRingtone?.play()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun vibrateDevice() {
        try {
            val vib = getSystemService(Vibrator::class.java)
            val pattern = longArrayOf(0, 500, 200, 500, 200, 800)
            vib?.vibrate(pattern, -1)
        } catch (ignored: Exception) {}
    }

    private fun stopAlarm() {
        try {
            if (currentRingtone?.isPlaying == true) {
                currentRingtone?.stop()
            }
        } catch (ignored: Exception) {}
        currentRingtone = null
    }

    private fun updateMonitorNotification(pct: Int, isCharging: Boolean) {
        val nm = getSystemService(NotificationManager::class.java)
        nm?.notify(NOTIF_ID_MONITOR, buildMonitorNotification(pct, isCharging))
    }

    private fun buildMonitorNotification(pct: Int, isCharging: Boolean): Notification {
        val text = if (isCharging) {
            "Charging: ${if (pct > 0) "$pct%" else "detecting..."} • Monitoring alerts"
        } else {
            "Unplugged • Connect charger to monitor"
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else PendingIntent.FLAG_UPDATE_CURRENT

        val openIntent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stopIntent = PendingIntent.getService(this, 1, Intent(this, ChargeService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }, flags)

        return Notification.Builder(this, CHANNEL_MONITOR)
            .setContentTitle("Charge Alert Active")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopIntent)
            .build()
    }

    private fun showAlarmNotification(pct: Int, threshold: Int) {
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else PendingIntent.FLAG_UPDATE_CURRENT

        val dismissIntent = PendingIntent.getService(this, 2, Intent(this, ChargeService::class.java).apply {
            action = ACTION_DISMISS_ALARM
        }, flags)

        val openIntent = PendingIntent.getActivity(this, 3, Intent(this, MainActivity::class.java), flags)

        val notif = Notification.Builder(this, CHANNEL_ALARM)
            .setContentTitle("Battery reached $threshold%!")
            .setContentText("Target charge level reached. Unplug device to preserve battery life.")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentIntent(openIntent)
            .setAutoCancel(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Dismiss Alert", dismissIntent)
            .apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    setCategory(Notification.CATEGORY_ALARM)
                }
            }
            .build()

        val nm = getSystemService(NotificationManager::class.java)
        nm?.notify(NOTIF_ID_ALARM, notif)
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val monChannel = NotificationChannel(
                CHANNEL_MONITOR,
                "Monitoring Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply { setSound(null, null) }

            val alarmChannel = NotificationChannel(
                CHANNEL_ALARM,
                "Charge Alarm",
                NotificationManager.IMPORTANCE_HIGH
            )
            nm?.createNotificationChannel(monChannel)
            nm?.createNotificationChannel(alarmChannel)
        }
    }
}
